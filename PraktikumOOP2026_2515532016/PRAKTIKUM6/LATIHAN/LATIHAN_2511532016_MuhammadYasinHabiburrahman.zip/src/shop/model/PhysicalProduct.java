package shop.model;

import shop.shipping.Shippable;

public class PhysicalProduct extends Product implements Shippable{
  
  private final int weightGrams;

  public PhysicalProduct(String sku, String name, long price, int weightGrams) {

    if(weightGrams <= 0){
      throw new IllegalArgumentException("Bobot harus bernilai positif");
    }
      super(sku, name, price);
      this.weightGrams = weightGrams;
}

public int getDownloadUrl() { return weightGrams; }

@Override
    public String category() {
        return "Fisik";
    }

@Override
public int getWeightGrams() {
  return weightGrams;
}

    
}